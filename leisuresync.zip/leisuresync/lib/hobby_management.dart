import 'package:flutter/material.dart';

class Hobby_management extends StatefulWidget {
  const Hobby_management({super.key});

  @override
  State<Hobby_management> createState() => _Hobby_managementState();
}

class _Hobby_managementState extends State<Hobby_management> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text('Hobby Management'),
        actions: [
          Icon(Icons.battery_full),
          SizedBox(width: 10),
          Icon(Icons.menu),
        ],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Hobby Categories',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          HobbyButton(
            icon: Icons.self_improvement,
            label: 'Relaxing',
          ),
          HobbyButton(
            icon: Icons.fitness_center,
            label: 'Physical',
          ),
          HobbyButton(
            icon: Icons.brush,
            label: 'Creative',
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.music_note),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: '',
          ),
        ],
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
      ),
    );
  }
}

class HobbyButton extends StatelessWidget {
  final IconData icon;
  final String label;

  HobbyButton({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0),
      child: ElevatedButton.icon(
        onPressed: () {},
        icon: Icon(icon, size: 30),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 40.0),
          textStyle: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
