import 'package:flutter/material.dart';

class progress_tracker extends StatefulWidget {
  @override
  _progress_trackerState createState() => _progress_trackerState();
}

class _progress_trackerState extends State<progress_tracker> {
  int _selectedIndex = 0;
  static const List<Widget> _widgetOptions = <Widget>[
    Text('Robot Page'),
    Text('Home Page'),
    Text('Calendar Page'),
    Text('Notifications Page'),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Progress Tracker'),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            icon: Icon(Icons.menu),
            onPressed: () {},
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text('User'),
              accountEmail: null,
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.person,
                  size: 50.0,
                  color: Colors.blue,
                ),
              ),
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
            ),
            ListTile(
              title: Text('Account'),
              onTap: () {
                // Handle the Account tap
              },
            ),
            ListTile(
              title: Text('Edit Profile'),
              onTap: () {
                // Handle the Edit Profile tap
              },
            ),
            ListTile(
              title: Text('Logout'),
              onTap: () {
                // Handle the Logout tap
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Text(
            'Progress Tracker',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Container(
            height: 200,
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: _widgetOptions.elementAt(_selectedIndex),
          ),
          SizedBox(height: 20),
          Text(
            'Hobby: Basketball',
            style: TextStyle(fontSize: 18),
          ),
          Text(
            'Time Spent: 30 Minutes',
            style: TextStyle(fontSize: 18),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.room),
            label: 'Robot',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Chart',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Calendar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Notifications',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
    );
  }
}

class BarChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Bar(color: Colors.red, height: 150),
        Bar(color: Colors.blue, height: 50),
        Bar(color: Colors.green, height: 100),
        Bar(color: Colors.yellow, height: 150),
        Bar(color: Colors.purple, height: 20),
      ],
    );
  }
}

class Bar extends StatelessWidget {
  final Color color;
  final double height;

  Bar({required this.color, required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 30,
      height: height,
      color: color,
    );
  }
}
