import 'package:flutter/material.dart';

class Relaxing_hf extends StatefulWidget {
  @override
  _Relaxing_hfState createState() => _Relaxing_hfState();
}

class _Relaxing_hfState extends State<Relaxing_hf> {
  String? selectedHobby;
  String? selectedFrequency;
  String? selectedDuration;
  bool isFormValid = false;

  // Function to check if the form is valid
  void _checkFormValidity() {
    if (selectedHobby != null && selectedFrequency != null && selectedDuration != null) {
      setState(() {
        isFormValid = true;
      });
    } else {
      setState(() {
        isFormValid = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Relaxing Hobby'),
        backgroundColor: Colors.blue,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text('User'),
              accountEmail: null,
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.person,
                  size: 50.0,
                  color: Colors.blue,
                ),
              ),
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
            ),
            ListTile(
              title: Text('Account'),
              onTap: () {
                // Handle the Account tap
              },
            ),
            ListTile(
              title: Text('Edit Profile'),
              onTap: () {
                // Handle the Edit Profile tap
              },
            ),
            ListTile(
              title: Text('Logout'),
              onTap: () {
                // Handle the Logout tap
              },
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hobby:',
              style: TextStyle(fontSize: 18),
            ),
            DropdownButton<String>(
              value: selectedHobby,
              hint: Text('Select a hobby'),
              items: <String>['Reading', 'Gardening', 'Meditation', 'Cooking']
                  .map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedHobby = newValue;
                  _checkFormValidity();  // Check form validity on change
                });
              },
            ),
            SizedBox(height: 16),
            Text(
              'Frequency:',
              style: TextStyle(fontSize: 18),
            ),
            DropdownButton<String>(
              value: selectedFrequency,
              hint: Text('Select Frequency'),
              items: <String>['Daily', 'Weekly', 'Monthly'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedFrequency = newValue;
                  _checkFormValidity();  // Check form validity on change
                });
              },
            ),
            SizedBox(height: 16),
            Text(
              'Duration:',
              style: TextStyle(fontSize: 18),
            ),
            DropdownButton<String>(
              value: selectedDuration,
              hint: Text('Select Duration'),
              items: <String>['30 minutes', '1 hour', '2 hours'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedDuration = newValue;
                  _checkFormValidity();  // Check form validity on change
                });
              },
            ),
            SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: () {
                    // Handle back action
                  },
                  child: Text('Back'),
                ),
                ElevatedButton(
                  onPressed: isFormValid
                      ? () {
                    // Handle save action
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Form Saved Successfully!')),
                    );
                  }
                      : null,
                  child: Text('Save'),
                  style: ButtonStyle(
                    backgroundColor: WidgetStateProperty.all(
                      isFormValid ? Colors.blue : Colors.grey,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            if (!isFormValid) ...[
              Text(
                'Please fill out all fields to enable the save button.',
                style: TextStyle(color: Colors.red, fontSize: 16),
              ),
            ],
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.show_chart),
            label: 'Stats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Calendar',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Notifications',
          ),
        ],
        selectedItemColor: Colors.blue,
      ),
    );
  }
}
