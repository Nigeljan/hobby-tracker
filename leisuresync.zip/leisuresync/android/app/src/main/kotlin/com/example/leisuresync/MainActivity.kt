package com.example.leisuresync

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
